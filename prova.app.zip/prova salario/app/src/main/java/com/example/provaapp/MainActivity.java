package com.example.provaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText eSalario, eNome;
    Button bCorrer;
    double salario, salarioliquid;
    String nome, auxilio;
    int desconto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eSalario = findViewById(R.id.edtsal);
        eNome = findViewById(R.id.edtnome);
        bCorrer = findViewById(R.id.btnrun);
    }
    public void getInfo(View view){
        if(eSalario.getText().toString().isEmpty() && eNome.getText().toString().isEmpty()){
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else {
            salario = Double.parseDouble(eSalario.getText().toString());
            nome = eNome.getText().toString();
            if(salario <= 1000){
                desconto = 7;
                salarioliquid = (salario - salario*0.07) + 120;
                auxilio = "SIM";
            } else {
                if(salario > 1000 && salario <= 2000){
                    desconto = 10;
                    salarioliquid = (salario - salario*0.1);
                    auxilio = "NÃO";
                } else {
                    if(salario > 2000){
                        desconto = 15;
                        salarioliquid = (salario - salario*0.15);
                        auxilio = "NÃO";
                    }
                }
            }
            Intent intent = new Intent(this, segunda.class);
            intent.putExtra("nome", nome);
            intent.putExtra("liquidSal", salarioliquid);
            intent.putExtra("desconto", desconto);
            intent.putExtra("auxilio", auxilio);
            startActivity(intent);
            finish();
        }
    }

}
