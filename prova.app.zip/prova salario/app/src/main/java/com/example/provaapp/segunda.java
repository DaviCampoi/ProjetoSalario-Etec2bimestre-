package com.example.provaapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class segunda extends AppCompatActivity {
    TextView txtNome, txtSal, txtDis, txtAux;
    Intent thisIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);
        txtNome = findViewById(R.id.txtaaa);
        txtSal = findViewById(R.id.txtsal);
        txtDis = findViewById(R.id.txtdis);
        txtAux = findViewById(R.id.txtaux);
        thisIntent = this.getIntent();
        txtNome.setText(thisIntent.getStringExtra("nome"));
        txtSal.setText(String.valueOf(thisIntent.getDoubleExtra("liquidSal", 0)));
        txtDis.setText(String.valueOf(thisIntent.getIntExtra("desconto", 0)) + "%");
        txtAux.setText(thisIntent.getStringExtra("auxilio"));
    }
    public void Retorno(View view){
        Intent ni = new Intent(this, MainActivity.class);
        startActivity(ni);
}
}